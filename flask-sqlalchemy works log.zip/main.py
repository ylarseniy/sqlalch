from flask import Flask, render_template
from data import db_session, jobs, users
import random
import datetime
import string

app = Flask(__name__)
app.config['SECRET_KEY'] = 'yandexlyceum_secret_key'
db_session.global_init("db/blogs.sqlite")
session = db_session.create_session()


def _add_to_db():
    global session

    usr = users.User()
    usr.surname = 'Scott'
    usr.name = 'Ridley'
    usr.age = 21
    usr.position = 'captain'
    usr.speciality = 'research engineer'
    usr.address = 'module_1'
    usr.email = 'scott_chief@mars.org'
    session.add(usr)
    session.commit()

    usr = users.User()
    usr.surname = 'Weir'
    usr.name = 'Andy'
    usr.age = 21
    usr.position = 'Not captain'
    usr.speciality = 'Not research engineer'
    usr.address = 'module_1'
    usr.email = 'weir_chief2@mars.org'
    session.add(usr)
    session.commit()

    job = jobs.Jobs()
    job.team_leader = 1
    job.job = "deployment of residential modules 1 and 2"
    job.work_size = 15
    job.collaborators = "2, 3"
    job.start_date = datetime.datetime.now()
    job.is_finished = False
    session.add(job)
    session.commit()

    job = jobs.Jobs()
    job.team_leader = 2
    job.job = "Exploration of mineral resources"
    job.work_size = 15
    job.collaborators = "4, 3"
    job.start_date = datetime.datetime.now()
    job.is_finished = False
    session.add(job)
    session.commit()


@app.route('/')
@app.route('/log')
def index():
    _jobs = []
    current_job = {}
    for job in session.query(jobs.Jobs).all():
        current_job['id'] = job.id
        team_leader = session.query(users.User).filter(users.User.id == job.team_leader)[0]
        current_job['team_leader'] = f"{team_leader.name} {team_leader.surname}"
        current_job['job'] = job.job
        current_job['work_size'] = job.work_size
        current_job['collaborators'] = job.collaborators
        current_job['start_date'] = job.start_date
        current_job['end_date'] = job.end_date
        current_job['is_finished'] = job.is_finished
        _jobs.append(current_job)
        current_job = {}
    return render_template('log.html', jobs=_jobs)


if __name__ == '__main__':
    app.run(port=5000, host='localhost', debug=True)
